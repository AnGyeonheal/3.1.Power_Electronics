#include <math.h>
#include <stdio.h>
// test2 03/16 
double Vsa, Isa, DV;
int TUpdate;
double Psa, flag;
static int i = 0;
static double Psa_old = 0, Vsa_old = 0, Vref = 0, Isa_old = 0, Duty = 0, dD = 0.01;
double Verr, Duty_old, Verr_old, Verr_int = 0;
double Kp = 0.0380, Ki = 0.0380;
double delta_V = 0, delta_I = 0, Dslope = 0, slope = 0;
double Ts = 0.001;
double Df;
double dV, dI, dP;
double alpha, beta, gamma;


__declspec(dllexport)void simuser(double t, double dt, double* in, double* out) {

    Vsa = in[0];
    Isa = in[1];
    DV = in[2];
    TUpdate = in[3];

    i = 3 * t / Ts;

    if (i % TUpdate == 0) {

        //========Perturb & Obeserve MPPT========

        alpha = 0.0001;
        beta = 0.01;
        gamma = 0.01;

        Psa = Vsa * Isa;
        dV = Vsa - Vsa_old;
        dI = Isa - Isa_old;
        dP = Psa - Psa_old;

        if (fabs(dV) <= alpha) {
            if (fabs(dI) <= beta) {
                Vref = Vref;
            }
            else {
                if (dI > 0) {
                    Vref += DV;
                }
                else {
                    Vref -= DV;
                }
            }
        }
        else {
            if (fabs(dP / dV) <= gamma) {
                Vref = Vref;
            }
            else {
                if (dP / dV > 0) {
                    Vref += DV;
                }
                else {
                    Vref -= DV;
                }
            }
        }

        Psa_old = Psa;
        Vsa_old = Vsa;
        Isa_old = Isa;
    }

    // Voltage controller

    Verr = Vsa - Vref;
    Verr_int += Ki * Verr;

    Duty = Kp * Verr + Ki * Verr_int;

    Duty_old = Duty;
    Verr_old = Verr;

    out[0] = Duty;
    out[1] = Verr;
    out[2] = Vref;
}